import config

print(config.eventType)
print(config.eventCommand)
print(config.eventView)
print(config.eventContent)
